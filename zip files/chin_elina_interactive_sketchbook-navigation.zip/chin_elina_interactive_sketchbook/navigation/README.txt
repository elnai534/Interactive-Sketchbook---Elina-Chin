PORTFOLIO NAVIGATION — COPY AND PASTE

The navigation is already installed on all seven original HTML pages.
Open index.html to view the updated site. No install or build is needed.
All six menu destinations and the existing Page Two links are retained.

To reuse it:
1. Copy the navigation folder into your other site.
2. Copy the <nav> block from navigation.html into the page body,
   replacing any old main navigation.
3. After the existing stylesheet in <head>, add:
   <link rel="stylesheet" href="navigation/navigation.css">
   <script src="navigation/navigation.js" defer></script>
4. Include <meta name="viewport" content="width=device-width, initial-scale=1">.
5. Change the six href values to your destination pages.
   For pages one folder deep, prefix shared file paths and destinations
   with ../; for pages two folders deep, use ../../.

Behavior:
- Fixed gray pill, white border, 300ms width transition.
- Shows links at the very top, including initial load.
- Below the top, expands while hovered and collapses on pointer exit.
- Scrolling partway upward does not open it; reaching the top does.
- On touchscreens, tap the collapsed pill to open. Scroll or tap outside
  to close when away from the top. Keyboard users can focus and activate it.
- Links wrap on narrow screens. Reduced-motion settings are respected.
- Shared body padding keeps content below the fixed navigation;
  scroll-padding leaves room for in-page targets.

The source portfolio uses React/Next.js. This isolated version uses plain
HTML, CSS, and JavaScript and works when opened directly as a local file.
